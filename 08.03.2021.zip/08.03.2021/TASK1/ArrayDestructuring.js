const num = ['one', 'two', 'three'];

const [red, yellow, green] = num;
console.log(red);
console.log(yellow); 
console.log(green); 